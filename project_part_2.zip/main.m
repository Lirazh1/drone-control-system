%Q6_1
Q6_1
open_system('Q_6_1');
load_system('Q_6_1');
out13=sim('Q_6_1');
t = out13.x.time  ;        
z6_1 = out13.z.signals.values; 
x6_1 = out13.x.signals.values; 
theta6_1 = out13.theta.signals.values; 
z_dot_6_1 = out13.z_dot.signals.values; 
x_dot_6_1 = out13.x_dot.signals.values; 
theta_dot_6_1 = out13.theta_dot.signals.values; 
figure;
hold on;
plot(t, x6_1, 'LineWidth', 1.5);
plot(t, x_dot_6_1, 'LineWidth', 1.5);
plot(t, z6_1, 'LineWidth', 1.5);
plot(t,z_dot_6_1 , 'LineWidth', 1.5);
plot(t, theta6_1, 'LineWidth', 1.5);
plot(t, theta_dot_6_1, 'LineWidth', 1.5);
legend('x [m]', 'x\_dot [m/s]', 'z [m]', 'z\_dot [m/s]', 'theta [rad]', ...
    'theta\_dot [rad/s]');
xlabel('time [sec] ');
ylabel('value');
title(['response of linearized system with LQR control']);
grid on;
%Q6_2
Q6_1
open_system('Q6_2');
load_system('Q6_2');
out14=sim('Q6_2');
t = out14.x_with_noise.time;        
z6_2 = out14.z_with_noise.signals.values; 
x6_2 = out14.x_with_noise.signals.values; 
theta6_2 = out14.theta_with_noise.signals.values;  
figure;
hold on;
plot(t, x6_2, 'LineWidth', 1.5);
plot(t, z6_2, 'LineWidth', 1.5);
plot(t, theta6_2, 'LineWidth', 1.5);
legend('x [m]', 'z [m]',  'theta [rad]');
xlabel('time [sec] ');
ylabel('value');
title(['response of linearized system with LQR control after adding ' ...
    'noise']);
grid on;
%Q6_3
Q6_1
Q6_3
open_system('Q_6_3');
load_system('Q_6_3');
out15=sim('Q_6_3');
t = out15.x.time  ;        
z6_3 = out15.z.signals.values; 
x6_3 = out15.x.signals.values; 
theta6_3 = out15.theta.signals.values; 
z_dot_6_3 = out15.z_dot.signals.values; 
x_dot_6_3 = out15.x_dot.signals.values; 
theta_dot_6_3 = out15.theta_dot.signals.values; 
z_est_6_3 = out15.z_est.signals.values; 
x_est_6_3 = out15.x_est.signals.values; 
theta_est_6_3 = out15.theta_est.signals.values; 
z_dot_est_6_3 = out15.z_dot_est.signals.values; 
x_dot_est_6_3 = out15.x_dot_est.signals.values; 
theta_dot_est_6_3 = out15.theta_dot_est.signals.values;
colors = hsv(12);
figure;
hold on;
plot(t, x6_3, '-', 'Color', colors(1,:), 'LineWidth', 1.5); 
plot(t, x_dot_6_3, '-', 'Color', colors(5,:), 'LineWidth', 1.5); 
plot(t, z6_3, '-', 'Color', colors(9,:), 'LineWidth', 1.5); 
plot(t,z_dot_6_3 ,'-', 'Color', colors(2,:), 'LineWidth', 1.5); 
plot(t, theta6_3,'-', 'Color', colors(6,:), 'LineWidth', 1.5); 
plot(t, theta_dot_6_3, '-', 'Color', colors(10,:), 'LineWidth', 1.5); 
plot(t, x_est_6_3,'-', 'Color', colors(4,:), 'LineWidth', 1.5); 
plot(t, x_dot_est_6_3, '-', 'Color', colors(7,:), 'LineWidth', 1.5); 
plot(t, z_est_6_3, '-', 'Color', colors(12,:), 'LineWidth', 1.5); 
plot(t,z_dot_est_6_3 ,'-', 'Color', colors(3,:), 'LineWidth', 1.5); 
plot(t, theta_est_6_3, '-', 'Color', colors(11,:), 'LineWidth', 1.5); 
plot(t, theta_dot_est_6_3, '-', 'Color', colors(8,:), 'LineWidth', 1.5); 

legend('x [m]', 'x\_dot [m/s]', 'z [m]', 'z\_dot [m/s]', 'theta [rad]', ...
    'theta\_dot [rad/s]','x\_est [m]', 'x\_dot\_est [m/s]', ...
    'z\_est [m]','z\_dot\_est [m/s]', 'theta\_est [rad]', ...
    'theta\_dot\_est [rad/s]');
xlabel('time [sec] ');
ylabel('value');
title(['true state vs estimated state using kalman filter']);
grid on;
%Q6_4
Q6_1
Q6_3
open_system('Q_6_4');
load_system('Q_6_4');
out16=sim('Q_6_4');
t = out16.x.time  ;        
z6_4 = out16.z.signals.values; 
x6_4 = out16.x.signals.values; 
theta6_4 = out16.theta.signals.values; 
z_dot_6_4 = out16.z_dot.signals.values; 
x_dot_6_4 = out16.x_dot.signals.values; 
theta_dot_6_4 = out16.theta_dot.signals.values; 
z_est_6_4 = out16.z_est.signals.values; 
x_est_6_4 = out16.x_est.signals.values; 
theta_est_6_4 = out16.theta_est.signals.values; 
z_dot_est_6_4 = out16.z_dot_est.signals.values; 
x_dot_est_6_4 = out16.x_dot_est.signals.values; 
theta_dot_est_6_4 = out16.theta_dot_est.signals.values;
colors = hsv(12);
figure;
hold on;
plot(t, x6_4, '-', 'Color', colors(1,:), 'LineWidth', 1.5); 
plot(t, x_dot_6_4, '-', 'Color', colors(10,:), 'LineWidth', 1.5); 
plot(t, z6_4, '-', 'Color', colors(5,:), 'LineWidth', 1.5); 
plot(t,z_dot_6_4 ,'-', 'Color', colors(8,:), 'LineWidth', 1.5); 
plot(t, theta6_4,'-', 'Color', colors(2,:), 'LineWidth', 1.5); 
plot(t, theta_dot_6_4, '-', 'Color', colors(6,:), 'LineWidth', 1.5); 
plot(t, x_est_6_4,'-', 'Color', colors(9,:), 'LineWidth', 1.5); 
plot(t, x_dot_est_6_4, '-', 'Color', colors(12,:), 'LineWidth', 1.5); 
plot(t, z_est_6_4, '-', 'Color', colors(3,:), 'LineWidth', 1.5); 
plot(t,z_dot_est_6_4 ,'-', 'Color', colors(7,:), 'LineWidth', 1.5); 
plot(t, theta_est_6_4, '-', 'Color', colors(11,:), 'LineWidth', 1.5); 
plot(t, theta_dot_est_6_4, '-', 'Color', colors(4,:), 'LineWidth', 1.5); 
legend('x [m]', 'x\_dot [m/s]', 'z [m]', 'z\_dot [m/s]', 'theta [rad]', ...
    'theta\_dot [rad/s]','x\_est [m]', 'x\_dot\_est [m/s]', ...
    'z\_est [m]','z\_dot\_est [m/s]', 'theta\_est [rad]', ...
    'theta\_dot\_est [rad/s]');
xlabel('time [sec] ');
ylabel('value');
title(['true state vs estimated state using combined kalman filter and' ...
    ' LQR controller']);
grid on;
z6_4_with_noise = out16.z_with_noise.signals.values; 
x6_4_with_noise = out16.x_with_noise.signals.values; 
theta6_4_with_noise = out16.theta_with_noise.signals.values;  
figure;
hold on;
plot(t, x6_4_with_noise, 'LineWidth', 1.5);
plot(t,z6_4_with_noise, 'LineWidth', 1.5);
plot(t, theta6_4_with_noise, 'LineWidth', 1.5);
legend('x [m]', 'z [m]',  'theta [rad]');
xlabel('time [sec] ');
ylabel('value');
title(['response of linearized system using combined kalman filter and' ...
    ' LQR controller']);
grid on;
%Q6_5
Q6_1
Q6_3
open_system('Q_6_5');
load_system('Q_6_5');
out17=sim('Q_6_5');
t = out17.x.time  ;        
z6_5 = out17.z.signals.values; 
x6_5 = out17.x.signals.values; 
theta6_5 = out17.theta.signals.values; 
z_dot_6_5 = out17.z_dot.signals.values; 
x_dot_6_5 = out17.x_dot.signals.values; 
theta_dot_6_5 = out17.theta_dot.signals.values; 
z_est_6_5 = out17.z_est.signals.values; 
x_est_6_5 = out17.x_est.signals.values; 
theta_est_6_5 = out17.theta_est.signals.values; 
z_dot_est_6_5 = out17.z_dot_est.signals.values; 
x_dot_est_6_5 = out17.x_dot_est.signals.values; 
theta_dot_est_6_5 = out17.theta_dot_est.signals.values;
colors = hsv(12);
figure;
hold on;
plot(t, x6_5, '-', 'Color', colors(1,:), 'LineWidth', 1.5); 
plot(t, x_dot_6_5, '-', 'Color', colors(4,:), 'LineWidth', 1.5); 
plot(t, z6_5, '-', 'Color', colors(7,:), 'LineWidth', 1.5); 
plot(t,z_dot_6_5 ,'-', 'Color', colors(10,:), 'LineWidth', 1.5); 
plot(t, theta6_5,'-', 'Color', colors(2,:), 'LineWidth', 1.5); 
plot(t, theta_dot_6_5, '-', 'Color', colors(5,:), 'LineWidth', 1.5); 
plot(t, x_est_6_5,'-', 'Color', colors(8,:), 'LineWidth', 1.5); 
plot(t, x_dot_est_6_5, '-', 'Color', colors(11,:), 'LineWidth', 1.5); 
plot(t, z_est_6_5, '-', 'Color', colors(3,:), 'LineWidth', 1.5); 
plot(t,z_dot_est_6_5 ,'-', 'Color', colors(6,:), 'LineWidth', 1.5); 
plot(t, theta_est_6_5, '-', 'Color', colors(9,:), 'LineWidth', 1.5); 
plot(t, theta_dot_est_6_5, '-', 'Color', colors(12,:), 'LineWidth', 1.5); 
legend('x [m]', 'x\_dot [m/s]', 'z [m]', 'z\_dot [m/s]', 'theta [rad]', ...
    'theta\_dot [rad/s]','x\_est [m]', 'x\_dot\_est [m/s]', ...
    'z\_est [m]','z\_dot\_est [m/s]', 'theta\_est [rad]', ...
    'theta\_dot\_est [rad/s]');
xlabel('time [sec] ');
ylabel('value');
title(['true state vs estimated state using combined kalman filter' ...
    ' (which is designed for noise that is different from the real ' ...
    'noise in the system) and LQR controller']);
grid on;
z6_5_with_noise = out17.z_with_noise.signals.values; 
x6_5_with_noise = out17.x_with_noise.signals.values; 
theta6_5_with_noise = out17.theta_with_noise.signals.values;  
figure;
hold on;
plot(t, x6_5_with_noise, 'LineWidth', 1.5);
plot(t,z6_5_with_noise, 'LineWidth', 1.5);
plot(t, theta6_5_with_noise, 'LineWidth', 1.5);
legend('x [m]', 'z [m]',  'theta [rad]');
xlabel('time [sec] ');
ylabel('value');
title(['response of linearized system using combined kalman filter' ...
    ' (which is designed for noise that is different from the real ' ...
    'noise in the system) and LQR controller']);
grid on;