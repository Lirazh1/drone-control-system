%Q6_3
% matrix of linear system
A = [ 0     1     0     0     0     0;
     0     0     0     0  -9.8     0;
     0     0     0     1     0     0;
     0     0     0     0     0     0;
     0     0     0     0     0     1;
     0     0     0     0     0     0];
C = [1 0 0 0 0 0;
     0 0 1 0 0 0;
     0 0 0 0 1 0];

%computing noise covariances
covariance_of_w = 1e-5 * eye(6);   
covariance_of_v = 1e-5 * eye(3);   

% computing kalman gain
[L,~,~] = lqe(A, eye(6), C, covariance_of_w, covariance_of_v); 