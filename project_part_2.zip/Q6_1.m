%Q6_1
clc;
clear;
%parameters of the system
m =2;
L =0.54;
J =0.1;
g =9.8;
% matrix of linear system
A = [ 0     1     0     0     0     0;
     0     0     0     0  -9.8     0;
     0     0     0     1     0     0;
     0     0     0     0     0     0;
     0     0     0     0     0     1;
     0     0     0     0     0     0];
B = [ 0      0;
       0     0;
      0      0;
     1/m     0;
      0      0;
      0   L/J ];
%defining Q and R
Q = diag([1 1 1 1 1 1]);  
R = 3 * diag([1 1]);
% computing LQR gain
K_LQR = lqr(A, B, Q, R);


