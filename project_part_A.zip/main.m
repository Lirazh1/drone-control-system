%% 
close all
clearvars
clc
%Q2.3-2.4
open_system('proj_Q2_34');
load_system('proj_Q2_34');
out=sim('proj_Q2_34');
t = out.x.time  ;        
x = out.x.signals.values;  
x_dot = out.x_dot.signals.values;  
theta=out.theta.signals.values;  %in radians
theta=theta*(180/pi); %in degrees
theta_dot=out.theta_dot.signals.values; 
theta_dot=theta_dot*(180/pi);
z=out.z.signals.values;    
z_dot=out.z_dot.signals.values;
figure;
hold on;
plot(t, x, 'LineWidth', 1.5);  
plot(t, x_dot, 'LineWidth', 1.5);  
plot(t, z, 'LineWidth', 1.5);
plot(t, z_dot, 'LineWidth', 1.5);  
plot(t, theta, 'LineWidth', 1.5); 
plot(t, theta_dot, 'LineWidth', 1.5);  
xlabel('time [sec] ');
ylabel('values');
legend('x[m]','x.dot[m/sec]','z[m]','z.dot[m/sec]','theta[degrees]', ...
    'theta.dot[degrees/sec]');
title(['state variables of the non linearized system as a function of' ...
    ' time']);
grid on;
open_system('proQ_33');
load_system('proQ_33');
out1=sim('proQ_33');
t = out1.x.time  ;        
x_3 = out1.x.signals.values;  
x_dot_3 = out1.x_dot.signals.values;  
theta_3=out1.theta.signals.values;  %in radians
theta_3=theta_3*(180/pi); %in degrees
theta_dot_3=out1.theta_dot.signals.values; 
theta_dot_3=theta_dot_3*(180/pi);
z_3=out1.z.signals.values;    
z_dot_3=out1.z_dot.signals.values;
figure;
hold on;
plot(t, x_3, 'LineWidth', 1.5);  
plot(t, x_dot_3, 'LineWidth', 1.5);  
plot(t, z_3, 'LineWidth', 1.5);
plot(t, z_dot_3, 'LineWidth', 1.5);  
plot(t, theta_3, 'LineWidth', 1.5); 
plot(t, theta_dot_3, 'LineWidth', 1.5);  
xlabel('time [sec] ');
ylabel('values');
legend('x[m]','x.dot[m/sec]','z[m]', ...
    'z.dot[m/sec]' ...
    ,'theta[degrees]', ...
    'theta.dot[degrees/sec]');
title('state variables of the linearized system as a function of time');
grid on;
%Q4.2
open_system('proQ4_2');
load_system('proQ4_2');
out2=sim('proQ4_2');
t = out2.z.time  ;        
z4 = out2.z.signals.values; 
u14 = out2.u1.signals.values; 
figure;
hold on;
plot(t, u14, 'LineWidth', 1.5);  
plot(t, z4, 'LineWidth', 1.5); 
legend('u1[kg*(m/s^2)]','z[m]');
xlabel('time [sec] ');
ylabel('value');
title('output z in response to step function input');
grid on;
%Q4.3
open_system('proQ4_3');
load_system('proQ4_3');
out3=sim('proQ4_3');
t = out3.z.time  ;        
z4_3 = out3.z.signals.values; 
u4_3 = out3.u1.signals.values; 
figure;
hold on;
plot(t, u4_3, 'LineWidth', 1.5);  
plot(t, z4_3, 'LineWidth', 1.5); 
legend('u1[kg*(m/s^2)]','z[m]');
xlabel('time [sec] ');
ylabel('value');
title(['output z in response to step function input in a closed loop' ...
    ' system']);
grid on;
%Q4_5
open_system('proQ4_5');
load_system('proQ4_5');
out4=sim('proQ4_5');
t = out4.z.time  ;        
z4_5 = out4.z.signals.values; 
r4_5 = out4.r.signals.values; 
figure;
hold on;
plot(t, z4_5, 'LineWidth', 1.5);
plot(t, r4_5, 'LineWidth', 1.5); 
legend('z[m]','r');
xlabel('time [sec] ');
ylabel('value');
title(['output z in response to step function with PID' ...
   ' controller (w/o g constant)']);
grid on;
%with g constant
open_system('proQ4_5_2');
load_system('proQ4_5_2');
out5=sim('proQ4_5_2');
t = out5.z.time  ;        
z4_5_2 = out5.z.signals.values; 
r4_5_2 = out5.r.signals.values; 
figure;
hold on;
plot(t, z4_5_2, 'LineWidth', 1.5);
plot(t, r4_5_2, 'LineWidth', 1.5);
legend('z[m]','r');
xlabel('time [sec] ');
ylabel('value');
title(['output z in response to step function with PID' ...
   ' controller and with g constant']);
grid on;
project_Q53
%Q5.3
open_system('proje5_3');
load_system('proje5_3');
out6=sim('proje5_3');
t = out6.delta_z.time  ;        
delta_z5_3 = out6.delta_z.signals.values; 
delta_x5_3 = out6.delta_x.signals.values; 
delta_theta5_3 = out6.delta_theta.signals.values; 
figure;
hold on;
plot(t, delta_z5_3, 'LineWidth', 1.5);
plot(t, delta_x5_3, 'LineWidth', 1.5);
plot(t, delta_theta5_3, 'LineWidth', 1.5);
legend('delta_z[m]','delta_x[m]','delta_theta[radians]');
xlabel('time [sec] ');
ylabel('value');
title(['linear system response to input 0']);
grid on;
%Q5.4
open_system('proQ5_4_1');
load_system('proQ5_4_1');
out7=sim('proQ5_4_1');
t = out7.z.time  ;        
z5_4_1 = out7.z.signals.values; 
x5_4_1= out7.x.signals.values; 
theta5_4_1 = out7.theta.signals.values; 
z_dot_5_4_1 = out7.z_dot.signals.values; 
theta_dot_5_4_1 = out7.theta_dot.signals.values; 
x_dot_5_4_1 = out7.x_dot.signals.values; 
figure;
hold on;
plot(t,z5_4_1 , 'LineWidth', 1.5);
plot(t,x5_4_1 , 'LineWidth', 1.5);
plot(t, theta5_4_1, 'LineWidth', 1.5);
plot(t, z_dot_5_4_1, 'LineWidth', 1.5);
plot(t, theta_dot_5_4_1, 'LineWidth', 1.5);
plot(t, x_dot_5_4_1, 'LineWidth', 1.5);
legend('z[m]','x[m]','theta[radians]','z_dot[m/s]','theta_dot[rad/s]', ...
  'x_dot[m/s]'  );
xlabel('time [sec] ');
ylabel('value');
title(['linear system response to the first initial condition']);
grid on;
%5.4.2
open_system('proQ5_4_2');
load_system('proQ5_4_2');
out8=sim('proQ5_4_2');
t = out8.z.time  ;        
z5_4_2 = out8.z.signals.values; 
x5_4_2= out8.x.signals.values; 
theta5_4_2 = out8.theta.signals.values; 
z_dot_5_4_2 = out8.z_dot.signals.values; 
theta_dot_5_4_2 = out8.theta_dot.signals.values; 
x_dot_5_4_2 = out8.x_dot.signals.values; 
figure;
hold on;
plot(t,z5_4_2 , 'LineWidth', 1.5);
plot(t,x5_4_2 , 'LineWidth', 1.5);
plot(t, theta5_4_2, 'LineWidth', 1.5);
plot(t, z_dot_5_4_2, 'LineWidth', 1.5);
plot(t, theta_dot_5_4_2, 'LineWidth', 1.5);
plot(t, x_dot_5_4_2, 'LineWidth', 1.5);
legend('z[m]','x[m]','theta[radians]','z_dot[m/s]','theta_dot[rad/s]', ...
  'x_dot[m/s]'  );
xlabel('time [sec] ');
ylabel('value');
title(['linear system response to the second initial condition']);
grid on;    
%5.4.3
open_system('proQ_5_4_3');
load_system('proQ_5_4_3');
out9=sim('proQ_5_4_3');
t = out9.z.time  ;        
z5_4_3 = out9.z.signals.values; 
x5_4_3= out9.x.signals.values; 
theta5_4_3 = out9.theta.signals.values; 
z_dot_5_4_3 = out9.z_dot.signals.values; 
theta_dot_5_4_3 = out9.theta_dot.signals.values; 
x_dot_5_4_3 = out9.x_dot.signals.values; 
figure;
hold on;
plot(t,z5_4_3 , 'LineWidth', 1.5);
plot(t,x5_4_3 , 'LineWidth', 1.5);
plot(t, theta5_4_3, 'LineWidth', 1.5);
plot(t, z_dot_5_4_3, 'LineWidth', 1.5);
plot(t, theta_dot_5_4_3, 'LineWidth', 1.5);
plot(t, x_dot_5_4_3, 'LineWidth', 1.5);
legend('z[m]','x[m]','theta[radians]','z_dot[m/s]','theta_dot[rad/s]', ...
  'x_dot[m/s]'  );
xlabel('time [sec] ');
ylabel('value');
title(['linear system response to the third initial condition']);
grid on;    
%5.5
t = out7.u1.time  ;        
u15_4_1 = out7.u1.signals.values; 
u25_4_1 = out7.u2.signals.values; 
figure;
hold on;
plot(t,u15_4_1 , 'LineWidth', 1.5);
plot(t,u25_4_1 , 'LineWidth', 1.5);
legend('u1[kg*m/(s^2)]','u2[kg*m/(s^2)]');
xlabel('time [sec] ');
ylabel('value');
title(['control signals for the first initial condition']);
grid on;    
t = out8.u1.time  ;        
u15_4_2 = out8.u1.signals.values;
u25_4_2 = out8.u2.signals.values;
figure;
hold on;
plot(t,u15_4_2 , 'LineWidth', 1.5);
plot(t,u25_4_2 , 'LineWidth', 1.5);
legend('u1[kg*m/(s^2)]','u2[kg*m/(s^2)]');
xlabel('time [sec] ');
ylabel('value');
title(['control signals for the second initial condition']);
grid on; 
t = out9.u1.time  ;        
u15_4_3 = out9.u1.signals.values; 
u25_4_3 = out9.u2.signals.values; 
figure;
hold on;
plot(t, u15_4_3, 'LineWidth', 1.5);
plot(t,u25_4_3 , 'LineWidth', 1.5);
legend('u1[kg*m/(s^2)]','u2[kg*m/(s^2)]');
xlabel('time [sec] ');
ylabel('value');
title(['control signals for the third initial condition']);
grid on;
%5.6
open_system('proQ5_6_1');
load_system('proQ5_6_1');
out10=sim('proQ5_6_1');
t = out10.x.time  ;        
x_5_6_1 = out10.x.signals.values;  
x_dot_5_6_1 = out10.x_dot.signals.values;  
theta_5_6_1=out10.theta.signals.values;  %in radians
theta_dot_5_6_1=out10.theta_dot.signals.values; 
z_5_6_1=out10.z.signals.values;    
z_dot_5_6_1=out10.z_dot.signals.values;
figure;
hold on;
plot(t, x_5_6_1, 'LineWidth', 1.5);  
plot(t, x_dot_5_6_1, 'LineWidth', 1.5);  
plot(t,z_5_6_1 , 'LineWidth', 1.5);
plot(t, z_dot_5_6_1, 'LineWidth', 1.5);  
plot(t,theta_5_6_1, 'LineWidth', 1.5); 
plot(t, theta_dot_5_6_1, 'LineWidth', 1.5);  
xlabel('time [sec] ');
ylabel('values');
legend('x[m]','x.dot[m/sec]','z[m]', ...
    'z.dot[m/sec]' ...
    ,'theta[radians]', ...
    'theta.dot[radians/sec]');
title(['state variables of the non-linearized system with victor k for' ...
    ' the first intial condition']);
grid on;
%5.6.2
open_system('projeQ5_6_2');
load_system('projeQ5_6_2');
out11=sim('projeQ5_6_2');
t = out11.x.time  ;        
x_5_6_2 = out11.x.signals.values;  
x_dot_5_6_2 = out11.x_dot.signals.values;  
theta_5_6_2=out11.theta.signals.values;  %in radians
theta_dot_5_6_2=out11.theta_dot.signals.values; 
z_5_6_2=out11.z.signals.values;    
z_dot_5_6_2=out11.z_dot.signals.values;
figure;
hold on;
plot(t, x_5_6_2, 'LineWidth', 1.5);  
plot(t, x_dot_5_6_2, 'LineWidth', 1.5);  
plot(t,z_5_6_2 , 'LineWidth', 1.5);
plot(t, z_dot_5_6_2, 'LineWidth', 1.5);  
plot(t,theta_5_6_2, 'LineWidth', 1.5); 
plot(t, theta_dot_5_6_2, 'LineWidth', 1.5);  
xlabel('time [sec] ');
ylabel('values');
legend('x[m]','x.dot[m/sec]','z[m]', ...
    'z.dot[m/sec]' ...
    ,'theta[radians]', ...
    'theta.dot[radians/sec]');
title(['state variables of the non-linearized system with victor k for' ...
    ' the second intial condition']);
grid on;
%5.4.3
open_system('proQ5_6_3');
load_system('proQ5_6_3');
out12=sim('proQ5_6_3');
t = out12.x.time  ;        
x_5_6_3 = out12.x.signals.values;  
x_dot_5_6_3 = out12.x_dot.signals.values;  
theta_5_6_3=out12.theta.signals.values;  %in radians
theta_dot_5_6_3=out12.theta_dot.signals.values; 
z_5_6_3=out12.z.signals.values;    
z_dot_5_6_3=out12.z_dot.signals.values;
figure;
hold on;
plot(t, x_5_6_3, 'LineWidth', 1.5);  
plot(t, x_dot_5_6_3, 'LineWidth', 1.5);  
plot(t,z_5_6_3 , 'LineWidth', 1.5);
plot(t, z_dot_5_6_3, 'LineWidth', 1.5);  
plot(t,theta_5_6_3, 'LineWidth', 1.5); 
plot(t, theta_dot_5_6_3, 'LineWidth', 1.5);  
xlabel('time [sec] ');
ylabel('values');
legend('x[m]','x.dot[m/sec]','z[m]', ...
    'z.dot[m/sec]' ...
    ,'theta[radians]', ...
    'theta.dot[radians/sec]');
title(['state variables of the non-linearized system with victor k for' ...
    ' the third intial condition']);
grid on;