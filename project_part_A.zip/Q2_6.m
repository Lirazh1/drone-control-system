close all
clearvars
clc

%% define the motion track 
load('x.mat');   
load('z.mat');   
load('theta.mat'); 
t       = x.Time;    
x      = x.Data; 
z      = z.Data; 
theta  = theta.Data; 
theta=theta*(180/pi);
% ------------------
%% animate
save_vid = true;
drone_animation_2D(t, x, z, theta, save_vid)
%% Coordinates in time graph
% --- 
figure;
plot(t, x, 'b', 'LineWidth', 1.5); hold on;
plot(t, z, 'r', 'LineWidth', 1.5);
plot(t, theta, 'g', 'LineWidth', 1.5);
xlabel('time [sec])');
ylabel('Value');
title('Drone Coordinates as a function of Time');
legend('x [m]', 'z [m]', 'theta [deg]');
grid on;
% ------------------