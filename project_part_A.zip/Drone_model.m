close all
clearvars
clc
 
%% define the motion track 
%Q1.1
sim_duration =10;
sim_framerate = 0.03;
f_s =0.5/(2*pi);
f_pitch=(pi/5)*f_s;
% --- Edit this code (1.1)
t      = 0:sim_framerate:sim_duration;   
x      = 0.5+0.5*sin(2*pi*f_s*t-pi/2);
z      = 0.2*t;        %check
pitch  = -90*cos(2*pi*f_pitch*t); %check
% ------------------

%% animate
save_vid = true;
drone_animation_2D(t, x, z, pitch, save_vid)

%% Coordinates in time graph
% --- Add your code here (1.2)
figure;
plot(t, x, 'b', 'LineWidth', 1.5); hold on;
plot(t, z, 'r', 'LineWidth', 1.5);
plot(t, pitch, 'g', 'LineWidth', 1.5);
xlabel('time [sec]');
ylabel('Value');
title('Drone Coordinates as a function of Time');
legend('x [m]', 'z [m]', 'theta [deg]');
grid on;
% ------------------