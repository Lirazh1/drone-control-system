close all
clearvars
clc

%% define the motion track 
load('delta_x.mat');   
load('delta_z.mat');   
load('delta_theta.mat'); 
t       = delta_x.Time;    
x      = delta_x.Data; 
z      = delta_z.Data; 
theta  = delta_theta.Data; 
% ------------------
%% animate
save_vid = true;
drone_animation_2D(t, x, z, theta, save_vid)
%% Coordinates in time graph
% --- 
figure;
plot(t, delta_x, 'b', 'LineWidth', 1.5); hold on;
plot(t, delta_z, 'r', 'LineWidth', 1.5);
plot(t, delta_theta, 'g', 'LineWidth', 1.5);
xlabel('time [sec])');
ylabel('Value');
title('Drone Coordinates as a function of Time');
legend('x [m]', 'z [m]', 'theta [deg]');
grid on;
% ------------------