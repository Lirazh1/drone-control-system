A = [0,1,0,0,0,0;
    0,0,0,0,-9.8,0;
    0,0,0,1,0,0;
    0,0,0,0,0,0;
    0,0,0,0,0,1;
    0,0,0,0,0,0]
B= [0,0;
    0,0;
    0,0;
    0.5,0;
    0,0;
    0,5.4]
C= [1,0,0,0,0,0;
    0,0,1,0,0,0;
    0,0,0,0,1,0]
Co = ctrb(A,B);
rank_Co = rank(Co);

Ob = obsv(A,C);
rank_Ob = rank(Ob);

n = size(A,1);

if rank_Co == n
    disp('The system is controllable');
else
    disp('The system is NOT controllable');
end

if rank_Ob == n
    disp('The system is observable');
else
    disp('The system is NOT observable');
end
