clc;
clear;
%parameters of the system
m =2;
L =0.54;
J =0.1;
g =9.8;
% matrix of linear system
A = [ 0     1     0     0     0     0;
     0     0     0     0  -9.8     0;
     0     0     0     1     0     0;
     0     0     0     0     0     0;
     0     0     0     0     0     1;
     0     0     0     0     0     0];
B = [ 0      0;
       0     0;
      0      0;
     1/m     0;
      0      0;
      0   L/J ];
%O.S. and settling time at 2%
OS = 0.1;         
ts = 1;             
% computing damping ratio and natural frequency 
zeta = -log(OS)/sqrt(pi^2 + (log(OS))^2);
wn   = 4 / (zeta * ts);
% desired dominant poles
p1 = -zeta*wn + wn*sqrt(1 - zeta^2)*1i;
p2 = -zeta*wn - wn*sqrt(1 - zeta^2)*1i;
%additional poles that are quicker X10 from the dominant poles so they do
%not affect the perfomance of the desired response
additonal_poles = [-40, -42, -44, -46]; % These can be adjusted
desired_poles = [p1, p2, additonal_poles];
% vector K
K = place(A, B, desired_poles);
disp('vector K is:');
disp(K)
% Anew 
A_new = A - B*K;


